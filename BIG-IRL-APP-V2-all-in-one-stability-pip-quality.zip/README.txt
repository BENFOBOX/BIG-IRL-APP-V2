BIG IRL APP V2 all-in-one stability patch

- Replaces the custom system overlay with native Android Picture-in-Picture.
- Adds a PiP STOP STREAM action and retains notification KILL STREAM.
- Removes Display-over-other-apps permission and frozen/shadow overlay failure mode.
- Repairs foreground preview refresh and avoids a secondary RootEncoder preview surface.
- Keeps stream-scoped cellular request from START through STOP/KILL/swipe-away.
- Removes duplicated portrait quality selector and large duplicate status card.
- Standardises all displayed rates to Kbps.
- Adds coloured/neutral Nano states and Tailscale telemetry fallback.
- Adds live +/-500 Kbps bitrate controls without camera/encoder rebuild.
- Preserves the direct IPv6 SRT endpoint and existing receiver behaviour.
