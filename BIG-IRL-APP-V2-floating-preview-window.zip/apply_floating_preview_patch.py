from pathlib import Path

manifest = Path('app/src/main/AndroidManifest.xml')
s = manifest.read_text()
if 'android.permission.SYSTEM_ALERT_WINDOW' not in s:
    s = s.replace(
        '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
        '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />',
    )
manifest.write_text(s)

activity = Path('app/src/main/java/uk/co/bigirl/sender/MainActivity.kt')
s = activity.read_text()
# Remove obsolete in-app quick-menu imports/overlay.
s = s.replace('import android.net.Uri\n', '')
quick_start = s.find('        var quickMenuOpen by remember { mutableStateOf(false) }')
if quick_start >= 0:
    quick_end = s.find('        if (!permissionsGranted) {', quick_start)
    if quick_end < 0:
        raise SystemExit('Could not find end of obsolete quick menu')
    s = s[:quick_start] + s[quick_end:]
# Add overlay permission imports.
if 'import android.provider.Settings' not in s:
    s = s.replace('import android.os.IBinder\n', 'import android.os.IBinder\nimport android.provider.Settings\n')
if 'import android.net.Uri' not in s:
    s = s.replace('import android.content.Intent\n', 'import android.content.Intent\nimport android.net.Uri\n')
# Activity foreground/background signalling and permission request.
old_create = '''    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BigIrlV2(service) }
    }'''
new_create = '''    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"),
                ),
            )
        }
        setContent { BigIrlV2(service) }
    }

    override fun onStart() {
        super.onStart()
        service?.setAppForeground(true)
    }

    override fun onStop() {
        service?.setAppForeground(false)
        super.onStop()
    }'''
if old_create not in s:
    raise SystemExit('MainActivity onCreate block not found')
s = s.replace(old_create, new_create, 1)
# Ensure newly connected service is told app is foreground.
s = s.replace(
    'service = (binder as StreamingService.LocalBinder).service()',
    'service = (binder as StreamingService.LocalBinder).service().also { it.setAppForeground(true) }',
    1,
)
activity.write_text(s)

service = Path('app/src/main/java/uk/co/bigirl/sender/StreamingService.kt')
s = service.read_text()
# Imports.
imports = '''import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.pedro.library.view.preview.MultiPreviewConfig
'''
if 'import android.view.WindowManager' not in s:
    s = s.replace('import android.util.Log\n', 'import android.util.Log\n' + imports)
# Fields.
field_marker = '    private var previewAttachInProgress = false\n'
fields = '''    private var previewAttachInProgress = false
    private lateinit var windowManager: WindowManager
    private var floatingPreview: FrameLayout? = null
    private var floatingSurfaceView: SurfaceView? = null
    private var floatingSurface: Surface? = null
    private var floatingStatus: TextView? = null
    private var floatingNetwork: TextView? = null
    private var floatingNano: TextView? = null
    private var appForeground = true
    private val showFloatingRunnable = Runnable { showFloatingPreviewIfNeeded() }
'''
if field_marker not in s:
    raise SystemExit('Service field marker not found')
s = s.replace(field_marker, fields, 1)
# Initialize WM.
s = s.replace('''        createStream()
        createNotificationChannel()''','''        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createStream()
        createNotificationChannel()''',1)
# Add foreground APIs before addListener.
marker = '    fun addListener(listener: Listener) {'
methods = '''    fun setAppForeground(foreground: Boolean) {
        appForeground = foreground
        mainHandler.removeCallbacks(showFloatingRunnable)
        if (foreground) {
            hideFloatingPreview()
        } else if (state.wantsStreaming) {
            mainHandler.postDelayed(showFloatingRunnable, 250L)
        }
    }

    private fun streamStatusLabel(): String = when {
        state.isStreaming -> "LIVE  ${state.bitrateKbps} Kbps"
        state.isReconnecting -> "RECONNECTING  0 Kbps"
        state.wantsStreaming -> "CONNECTING  0 Kbps"
        else -> "IDLE  0 Kbps"
    }

    private fun statusColour(): Int = when {
        state.isStreaming -> Color.rgb(81, 225, 166)
        state.isReconnecting || state.wantsStreaming -> Color.rgb(255, 184, 77)
        else -> Color.rgb(180, 190, 200)
    }

    private fun networkSummary(): String {
        val manager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        var wifi = false
        var cellular = false
        manager.allNetworks.forEach { network ->
            manager.getNetworkCapabilities(network)?.let { caps ->
                wifi = wifi || caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                cellular = cellular || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
            }
        }
        return "${if (wifi) "●" else "○"} Wi-Fi   ${if (cellular) "●" else "○"} SIM"
    }

    private fun updateFloatingOverlay() {
        floatingStatus?.apply {
            text = streamStatusLabel()
            setTextColor(statusColour())
        }
        floatingNetwork?.text = networkSummary()
        floatingNano?.apply {
            text = when {
                state.isStreaming -> "Nano live"
                state.isReconnecting -> "Nano reconnecting"
                state.wantsStreaming -> "Nano connecting"
                else -> "Nano idle"
            }
            setTextColor(statusColour())
        }
    }

    private fun showFloatingPreviewIfNeeded() {
        if (appForeground || !state.wantsStreaming || floatingPreview != null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return

        val density = resources.displayMetrics.density
        val width = (260 * density).toInt()
        val previewHeight = (146 * density).toInt()
        val totalHeight = (198 * density).toInt()

        val root = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.rgb(7, 16, 25))
                cornerRadius = 14 * density
                setStroke((2 * density).toInt(), Color.argb(220, 81, 225, 166))
            }
            setPadding((5 * density).toInt(), (5 * density).toInt(), (5 * density).toInt(), (5 * density).toInt())
            setOnClickListener {
                startActivity(
                    Intent(this@StreamingService, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    },
                )
            }
        }
        val surfaceView = SurfaceView(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, previewHeight))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((7 * density).toInt(), (3 * density).toInt(), (7 * density).toInt(), 0)
            background = ColorDrawable(Color.argb(215, 7, 16, 25))
        }
        fun line(size: Float, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            includeFontPadding = false
        }
        floatingStatus = line(11f, true).also(info::addView)
        floatingNetwork = line(9f).also(info::addView)
        floatingNano = line(9f).also(info::addView)
        root.addView(
            info,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM
            },
        )

        val params = WindowManager.LayoutParams(
            width,
            totalHeight,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (12 * density).toInt()
            y = (90 * density).toInt()
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragged = false
        root.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) dragged = true
                    params.x = (startX - dx).toInt()
                    params.y = (startY + dy).toInt().coerceAtLeast(0)
                    runCatching { windowManager.updateViewLayout(root, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) view.performClick()
                    true
                }
                else -> false
            }
        }
        surfaceView.holder.addCallback(object : android.view.SurfaceHolder.Callback {
            override fun surfaceCreated(holder: android.view.SurfaceHolder) {
                floatingSurface = holder.surface
                runCatching {
                    stream.addPreviewSurface(
                        holder.surface,
                        MultiPreviewConfig(width = width, height = previewHeight, aspectRatioMode = AspectRatioMode.Adjust),
                    )
                }.onFailure { Log.e(TAG, "Could not attach floating preview", it) }
            }
            override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) = Unit
            override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {
                runCatching { stream.removePreviewSurface(holder.surface) }
                floatingSurface = null
            }
        })
        floatingPreview = root
        floatingSurfaceView = surfaceView
        updateFloatingOverlay()
        runCatching { windowManager.addView(root, params) }
            .onFailure {
                Log.e(TAG, "Could not show floating preview", it)
                floatingPreview = null
                floatingSurfaceView = null
            }
    }

    private fun hideFloatingPreview() {
        floatingSurface?.let { surface -> runCatching { stream.removePreviewSurface(surface) } }
        floatingSurface = null
        floatingPreview?.let { runCatching { windowManager.removeView(it) } }
        floatingPreview = null
        floatingSurfaceView = null
        floatingStatus = null
        floatingNetwork = null
        floatingNano = null
    }

'''
if marker not in s:
    raise SystemExit('addListener marker missing')
s = s.replace(marker, methods + marker, 1)
# Need ColorDrawable import.
s = s.replace('import android.graphics.drawable.GradientDrawable\n','import android.graphics.drawable.GradientDrawable\nimport android.graphics.drawable.ColorDrawable\n')
# Show/hide with stream lifecycle.
s = s.replace('''        return connectNow()
    }''','''        val started = connectNow()
        if (!appForeground) mainHandler.postDelayed(showFloatingRunnable, 250L)
        return started
    }''',1)
s = s.replace('''        updateMessage(
            "Stream stopped",
        )''','''        hideFloatingPreview()
        updateMessage(
            "Stream stopped",
        )''',1)
# Update overlay on any state publish.
s = s.replace('''    private fun publishState() {
        val snapshot = state''','''    private fun publishState() {
        updateFloatingOverlay()
        val snapshot = state''',1)
# onTaskRemoved must hide and stop remains.
s = s.replace('''        stopStream()
        stopSelf()''','''        hideFloatingPreview()
        stopStream()
        stopSelf()''',1)
# onDestroy hide.
s = s.replace('''    override fun onDestroy() {
        userStopping = true''','''    override fun onDestroy() {
        mainHandler.removeCallbacks(showFloatingRunnable)
        hideFloatingPreview()
        userStopping = true''',1)
service.write_text(s)
print('PASS: floating preview patch applied')
