Corrected patch. It uses function-boundary matching so it works with the current multiline StreamingService.kt.

It fixes the RootEncoder 2.8.2 compile error by removing unsupported removePreviewSurface calls. The overlay is hidden while keeping its registered surface alive and is physically removed only after stream.release() during service destruction.

It also requests a cellular network only from START to STOP/KILL/swipe-away/service destruction, allowing Android Developer option Mobile data always active to remain off outside a livestream.
