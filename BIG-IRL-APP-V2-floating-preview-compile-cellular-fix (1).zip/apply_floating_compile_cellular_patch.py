from pathlib import Path
import re

manifest = Path('app/src/main/AndroidManifest.xml')
ms = manifest.read_text()
if 'android.permission.CHANGE_NETWORK_STATE' not in ms:
    anchor = '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />'
    if anchor not in ms:
        raise SystemExit('ACCESS_NETWORK_STATE permission not found')
    ms = ms.replace(anchor, anchor + '\n    <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />', 1)
manifest.write_text(ms)

p = Path('app/src/main/java/uk/co/bigirl/sender/StreamingService.kt')
s = p.read_text()
if 'showFloatingPreviewIfNeeded' not in s:
    raise SystemExit('Floating preview base patch is not present')

# RootEncoder 2.8.2 has addPreviewSurface but no removePreviewSurface.
s = re.sub(
    r'\s*runCatching\s*\{\s*stream\.removePreviewSurface\(holder\.surface\)\s*\}',
    '\n                // RootEncoder 2.8.2 keeps this secondary preview registered.\n',
    s,
)
s = re.sub(
    r'\s*floatingSurface\?\.let\s*\{\s*surface\s*->\s*runCatching\s*\{\s*stream\.removePreviewSurface\(surface\)\s*\}\s*\}',
    '\n        // The secondary preview is retained until stream.release().\n',
    s,
)
if 'stream.removePreviewSurface' in s:
    raise SystemExit('Unsupported stream.removePreviewSurface call remains')

# Reopen an existing hidden overlay instead of trying to recreate its surface.
old_guard = '        if (appForeground || !state.wantsStreaming || floatingPreview != null) return'
new_guard = '''        if (appForeground || !state.wantsStreaming) return
        floatingPreview?.let { root ->
            root.alpha = 1f
            root.isClickable = true
            (root.layoutParams as? WindowManager.LayoutParams)?.let { params ->
                params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                runCatching { windowManager.updateViewLayout(root, params) }
            }
            updateFloatingOverlay()
            return
        }'''
if old_guard in s:
    s = s.replace(old_guard, new_guard, 1)
elif 'params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()' not in s:
    raise SystemExit('Floating preview guard not found')

# Replace only the hideFloatingPreview body, regardless of formatting around stopStream.
hide_start = s.find('    private fun hideFloatingPreview() {')
if hide_start < 0:
    raise SystemExit('hideFloatingPreview function not found')
hide_end = s.find('\n    fun addListener(', hide_start)
if hide_end < 0:
    raise SystemExit('End of hideFloatingPreview function not found')
new_hide = '''    private fun hideFloatingPreview() {
        // Keep the WindowManager view and RootEncoder surface alive for this
        // GenericStream instance. Make it invisible and non-touchable while
        // BENFOBOX is foregrounded or the stream is stopped.
        floatingPreview?.let { root ->
            root.alpha = 0f
            root.isClickable = false
            (root.layoutParams as? WindowManager.LayoutParams)?.let { params ->
                params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                runCatching { windowManager.updateViewLayout(root, params) }
            }
        }
    }
'''
s = s[:hide_start] + new_hide + s[hide_end:]

# Cellular availability is held only for the lifetime of an intentional stream.
field_anchor = '    private val showFloatingRunnable = Runnable { showFloatingPreviewIfNeeded() }'
if 'private var cellularRequestActive' not in s:
    if field_anchor not in s:
        raise SystemExit('Floating runnable field not found')
    fields = field_anchor + '''
    private val connectivityManager by lazy {
        getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
    }
    private var cellularNetwork: android.net.Network? = null
    private var cellularRequestActive = false
    private val cellularCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: android.net.Network) {
            cellularNetwork = network
            updateFloatingOverlay()
        }

        override fun onLost(network: android.net.Network) {
            if (cellularNetwork == network) cellularNetwork = null
            updateFloatingOverlay()
        }
    }'''
    s = s.replace(field_anchor, fields, 1)

status_anchor = '    private fun streamStatusLabel(): String = when {'
if 'private fun holdCellularWhileStreaming()' not in s:
    if status_anchor not in s:
        raise SystemExit('streamStatusLabel function not found')
    methods = '''    private fun holdCellularWhileStreaming() {
        if (cellularRequestActive) return
        val request = android.net.NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()
        runCatching {
            connectivityManager.requestNetwork(request, cellularCallback)
            cellularRequestActive = true
        }.onFailure { Log.w(TAG, "Could not request cellular network", it) }
    }

    private fun releaseCellularHold() {
        if (!cellularRequestActive) return
        runCatching { connectivityManager.unregisterNetworkCallback(cellularCallback) }
        cellularRequestActive = false
        cellularNetwork = null
    }

'''
    s = s.replace(status_anchor, methods + status_anchor, 1)

# Insert at stable function boundaries rather than matching exact indentation blocks.
start_pos = s.find('    fun startSrt(')
connect_pos = s.find('\n    private fun connectNow()', start_pos)
if start_pos < 0 or connect_pos < 0:
    raise SystemExit('startSrt function boundaries not found')
start_block = s[start_pos:connect_pos]
if 'holdCellularWhileStreaming()' not in start_block:
    state_pos = start_block.find('        state = state.copy(')
    if state_pos < 0:
        raise SystemExit('startSrt state update not found')
    start_block = start_block[:state_pos] + '        holdCellularWhileStreaming()\n' + start_block[state_pos:]
    s = s[:start_pos] + start_block + s[connect_pos:]

stop_pos = s.find('    fun stopStream() {')
update_pos = s.find('\n    private fun updateMessage(', stop_pos)
if stop_pos < 0 or update_pos < 0:
    raise SystemExit('stopStream function boundaries not found')
stop_block = s[stop_pos:update_pos]
if 'releaseCellularHold()' not in stop_block:
    cancel_pos = stop_block.find('        cancelRetry()')
    if cancel_pos < 0:
        raise SystemExit('stopStream cancelRetry call not found')
    insert_pos = cancel_pos + len('        cancelRetry()')
    stop_block = stop_block[:insert_pos] + '\n        releaseCellularHold()' + stop_block[insert_pos:]
    s = s[:stop_pos] + stop_block + s[update_pos:]

# Final teardown: release network request and remove the overlay after stream.release().
destroy_pos = s.find('    override fun onDestroy() {')
acquire_pos = s.find('\n    private fun acquireWakeLock()', destroy_pos)
if destroy_pos < 0 or acquire_pos < 0:
    raise SystemExit('onDestroy function boundaries not found')
destroy_block = s[destroy_pos:acquire_pos]
if 'windowManager.removeView(root)' not in destroy_block:
    release_match = re.search(r'\n\s*runCatching\s*\{\s*stream\.release\(\)\s*\}', destroy_block)
    if not release_match:
        raise SystemExit('stream.release call in onDestroy not found')
    insert_pos = release_match.end()
    cleanup = '''
        releaseCellularHold()
        floatingPreview?.let { root -> runCatching { windowManager.removeView(root) } }
        floatingPreview = null
        floatingSurfaceView = null
        floatingSurface = null
        floatingStatus = null
        floatingNetwork = null
        floatingNano = null'''
    destroy_block = destroy_block[:insert_pos] + cleanup + destroy_block[insert_pos:]
    s = s[:destroy_pos] + destroy_block + s[acquire_pos:]

p.write_text(s)
print('PASS: compile fix and stream-scoped cellular request applied')
