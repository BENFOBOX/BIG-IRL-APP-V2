from pathlib import Path
import shutil
root=Path('.')
source=Path('all-in-one-patch')
files=[
'app/src/main/AndroidManifest.xml',
'app/src/main/java/uk/co/bigirl/sender/MainActivity.kt',
'app/src/main/java/uk/co/bigirl/sender/StreamingService.kt',
'app/src/main/java/uk/co/bigirl/sender/StreamBoxTelemetry.kt',
'app/src/main/java/uk/co/bigirl/sender/PipActionReceiver.kt',
]
for rel in files:
    src=source/rel; dst=root/rel
    if not src.is_file(): raise SystemExit(f'Missing patch file: {src}')
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
print('PASS: corrected all-in-one patch applied')
