BIG IRL APP V2 all-in-one stability patch v2
Corrected to remove every remaining custom WindowManager overlay cleanup reference.
