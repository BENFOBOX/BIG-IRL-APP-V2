from pathlib import Path

manifest = Path('app/src/main/AndroidManifest.xml')
ms = manifest.read_text()
if 'android.permission.CHANGE_NETWORK_STATE' not in ms:
    ms = ms.replace(
        '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
        '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />\n'
        '    <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />',
    )
manifest.write_text(ms)

p = Path('app/src/main/java/uk/co/bigirl/sender/StreamingService.kt')
s = p.read_text()

# Fix RootEncoder 2.8.2 build error: it has addPreviewSurface but no removePreviewSurface.
s = s.replace(
    '                runCatching { stream.removePreviewSurface(holder.surface) }\n                floatingSurface = null',
    '                // RootEncoder 2.8.2 has no removePreviewSurface API.\n'
    '                // Keep the registered surface for this GenericStream instance.\n'
    '                floatingSurface = null',
)
s = s.replace(
    '        floatingSurface?.let { surface -> runCatching { stream.removePreviewSurface(surface) } }\n        floatingSurface = null\n        floatingPreview?.let { runCatching { windowManager.removeView(it) } }\n        floatingPreview = null\n        floatingSurfaceView = null\n        floatingStatus = null\n        floatingNetwork = null\n        floatingNano = null',
    '''        // Keep the overlay and SurfaceView attached but make the window invisible and
        // non-touchable. This preserves the preview surface without relying on the
        // removePreviewSurface API that is absent in RootEncoder 2.8.2.
        floatingPreview?.let { root ->
            root.alpha = 0f
            root.isClickable = false
            (root.layoutParams as? WindowManager.LayoutParams)?.let { params ->
                params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                runCatching { windowManager.updateViewLayout(root, params) }
            }
        }''',
)

# If the overlay already exists, restore it instead of returning hidden.
s = s.replace(
    '        if (appForeground || !state.wantsStreaming || floatingPreview != null) return',
    '''        if (appForeground || !state.wantsStreaming) return
        floatingPreview?.let { root ->
            root.alpha = 1f
            root.isClickable = true
            (root.layoutParams as? WindowManager.LayoutParams)?.let { params ->
                params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                runCatching { windowManager.updateViewLayout(root, params) }
            }
            updateFloatingOverlay()
            return
        }''',
)

# Add cellular request fields.
field = '    private val showFloatingRunnable = Runnable { showFloatingPreviewIfNeeded() }\n'
addition = '''    private val showFloatingRunnable = Runnable { showFloatingPreviewIfNeeded() }
    private val connectivityManager by lazy {
        getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
    }
    private var cellularNetwork: android.net.Network? = null
    private var cellularRequestActive = false
    private val cellularCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: android.net.Network) {
            cellularNetwork = network
            updateFloatingOverlay()
        }
        override fun onLost(network: android.net.Network) {
            if (cellularNetwork == network) cellularNetwork = null
            updateFloatingOverlay()
        }
    }
'''
if field in s and 'cellularRequestActive' not in s:
    s = s.replace(field, addition, 1)

# Insert request/release methods before stream status helper.
marker = '    private fun streamStatusLabel(): String = when {'
methods = '''    private fun holdCellularWhileStreaming() {
        if (cellularRequestActive) return
        val request = android.net.NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()
        runCatching {
            connectivityManager.requestNetwork(request, cellularCallback)
            cellularRequestActive = true
        }.onFailure { Log.w(TAG, "Could not request cellular standby network", it) }
    }

    private fun releaseCellularHold() {
        if (!cellularRequestActive) return
        runCatching { connectivityManager.unregisterNetworkCallback(cellularCallback) }
        cellularRequestActive = false
        cellularNetwork = null
    }

'''
if marker in s and 'private fun holdCellularWhileStreaming()' not in s:
    s = s.replace(marker, methods + marker, 1)

# Activate only for an intentional stream, release on stop/service teardown.
needle = '''        state = state.copy(
            endpoint = clean,
            wantsStreaming = true,'''
if needle in s:
    s = s.replace(needle, '''        holdCellularWhileStreaming()
        state = state.copy(
            endpoint = clean,
            wantsStreaming = true,''', 1)
else:
    raise SystemExit('startSrt state block not found')

stop_needle = '''    fun stopStream() {
        userStopping = true
        cancelRetry()'''
if stop_needle in s:
    s = s.replace(stop_needle, '''    fun stopStream() {
        userStopping = true
        cancelRetry()
        releaseCellularHold()''', 1)
else:
    raise SystemExit('stopStream block not found')

# Properly remove Android window only after stream release in onDestroy.
destroy_marker = '''        runCatching {
            stream.release()
        }
        wakeLock'''
destroy_replacement = '''        runCatching {
            stream.release()
        }
        releaseCellularHold()
        floatingPreview?.let { root -> runCatching { windowManager.removeView(root) } }
        floatingPreview = null
        floatingSurfaceView = null
        floatingStatus = null
        floatingNetwork = null
        floatingNano = null
        wakeLock'''
if destroy_marker in s:
    s = s.replace(destroy_marker, destroy_replacement, 1)
else:
    raise SystemExit('onDestroy release marker not found')

if 'removePreviewSurface' in s.replace('no removePreviewSurface API', '').replace('removePreviewSurface API', ''):
    raise SystemExit('Unsupported removePreviewSurface call remains')

p.write_text(s)
print('PASS: floating preview compile fix and stream-only cellular hold applied')
