from pathlib import Path

service = Path('app/src/main/java/uk/co/bigirl/sender/StreamingService.kt')
text = service.read_text()
start = text.index('    override fun onConnectionSuccess() {')
end = text.index('    override fun onConnectionFailed(', start)
replacement = '''    override fun onConnectionSuccess() {
        Log.i(TAG, "SRT connected")
        retryIndex = 0
        state = state.copy(isStreaming = true, isReconnecting = false)
        updateMessage("Live over SRT")

        // Give the receiver a fresh decoder entry point as soon as SRT is established.
        // RootEncoder prepends the current codec configuration when requesting a keyframe.
        runCatching { stream.requestKeyframe() }
            .onFailure { Log.w(TAG, "Immediate keyframe request failed", it) }

        mainHandler.postDelayed({
            if (state.wantsStreaming && stream.isStreaming) {
                runCatching { stream.requestKeyframe() }
                    .onFailure { Log.w(TAG, "Follow-up keyframe request failed", it) }
            }
        }, 750L)
    }

'''
text = text[:start] + replacement + text[end:]
service.write_text(text)

activity = Path('app/src/main/java/uk/co/bigirl/sender/MainActivity.kt')
text = activity.read_text()
old_call = '''        ReceiverOverlay(
            modifier = Modifier.align(Alignment.TopEnd),
            telemetry = streamBoxTelemetry,
        )'''
new_call = '''        ReceiverOverlay(
            modifier = Modifier.align(Alignment.TopEnd),
            telemetry = streamBoxTelemetry,
            streamState = streamState,
        )'''
if old_call in text:
    text = text.replace(old_call, new_call, 1)
elif 'streamState = streamState,' not in text[text.index('ReceiverOverlay('):text.index('ReceiverOverlay(')+250]:
    raise SystemExit('ReceiverOverlay call site not found')

old_sig = '''private fun ReceiverOverlay(
    modifier: Modifier,
    telemetry: StreamBoxTelemetry,
) {'''
new_sig = '''private fun ReceiverOverlay(
    modifier: Modifier,
    telemetry: StreamBoxTelemetry,
    streamState: StreamingService.StreamState,
) {'''
if old_sig in text:
    text = text.replace(old_sig, new_sig, 1)
elif 'streamState: StreamingService.StreamState' not in text:
    raise SystemExit('ReceiverOverlay signature not found')

old_status = '''        Text(
            if (telemetry.online) "Nano ${"%.1f".format(telemetry.nanoTemperatureC)} C" else "Nano offline",
            color = if (telemetry.online) Color(0xFF51E1A6) else Color(0xFFFFC857),
            fontSize = 8.sp,
            lineHeight = 9.sp,
        )'''
new_status = '''        val nanoConnected = telemetry.online || streamState.isStreaming
        val nanoStatus = when {
            telemetry.online -> "Nano ${"%.1f".format(telemetry.nanoTemperatureC)} C"
            streamState.isStreaming -> "Nano live"
            streamState.isReconnecting -> "Nano reconnecting"
            else -> "Nano offline"
        }
        Text(
            nanoStatus,
            color = if (nanoConnected) Color(0xFF51E1A6) else Color(0xFFFFC857),
            fontSize = 8.sp,
            lineHeight = 9.sp,
        )'''
if old_status not in text:
    if 'val nanoConnected = telemetry.online || streamState.isStreaming' not in text:
        raise SystemExit('Nano status block not found')
else:
    text = text.replace(old_status, new_status, 1)
activity.write_text(text)
print('PASS: receiver baseline patch applied')
