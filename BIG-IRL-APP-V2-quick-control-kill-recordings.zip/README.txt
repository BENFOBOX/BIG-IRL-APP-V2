Adds an always-visible in-app floating menu with emergency STOP and Recordings, a notification KILL STREAM action, and stops the non-sticky service when the task is swiped away.
