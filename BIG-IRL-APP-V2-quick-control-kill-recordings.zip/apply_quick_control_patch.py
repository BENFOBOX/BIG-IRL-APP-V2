from pathlib import Path

manifest=Path('app/src/main/AndroidManifest.xml')
s=manifest.read_text().replace('android:stopWithTask="false"','android:stopWithTask="true"')
manifest.write_text(s)

svc=Path('app/src/main/java/uk/co/bigirl/sender/StreamingService.kt')
s=svc.read_text()
s=s.replace('private const val NOTIFICATION_ID = 1001','private const val NOTIFICATION_ID = 1001\n        const val ACTION_KILL_STREAM = "uk.co.bigirl.sender.KILL_STREAM"')
old='''        startForeground(
            NOTIFICATION_ID,
            notification(state.message),
        )

        acquireWakeLock()

        return START_STICKY'''
new='''        if (intent?.action == ACTION_KILL_STREAM) {
            stopStream()
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification(state.message))
        acquireWakeLock()
        return START_NOT_STICKY'''
if old not in s: raise SystemExit('onStartCommand block not found')
s=s.replace(old,new,1)
marker='''    override fun onDestroy() {'''
insert='''    override fun onTaskRemoved(rootIntent: Intent?) {
        // Swiping the app away is an explicit emergency stop.
        stopStream()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

'''
s=s.replace(marker,insert+marker,1)
old='''        return NotificationCompat.Builder(
            this,
            CHANNEL_ID,
        )'''
new='''        val killIntent = Intent(this, StreamingService::class.java).apply {
            action = ACTION_KILL_STREAM
        }
        val killPendingIntent = PendingIntent.getService(
            this, 1002, killIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(
            this,
            CHANNEL_ID,
        )'''
s=s.replace(old,new,1)
s=s.replace('''.setOnlyAlertOnce(true)
            .build()''','''.addAction(android.R.drawable.ic_menu_close_clear_cancel, "KILL STREAM", killPendingIntent)
            .setOnlyAlertOnce(true)
            .build()''',1)
svc.write_text(s)

act=Path('app/src/main/java/uk/co/bigirl/sender/MainActivity.kt')
s=act.read_text()
s=s.replace('import android.content.Intent','import android.content.Intent\nimport android.net.Uri')
# Add quick menu inside PreviewPanel box before permission prompt.
needle='''        if (!permissionsGranted) {
            Button(onClick = onPermissionRequest) {'''
block='''        var quickMenuOpen by remember { mutableStateOf(false) }
        Box(
            modifier = Modifier.align(Alignment.BottomEnd).padding(7.dp),
        ) {
            Button(onClick = { quickMenuOpen = true }) { Text("☰") }
            DropdownMenu(
                expanded = quickMenuOpen,
                onDismissRequest = { quickMenuOpen = false },
            ) {
                DropdownMenuItem(
                    text = { Text("STOP / KILL STREAM") },
                    enabled = streamState.wantsStreaming,
                    onClick = {
                        quickMenuOpen = false
                        service?.stopStream()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Recordings") },
                    onClick = {
                        quickMenuOpen = false
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("http://192.168.1.27:8081/"),
                        )
                        currentContext.startActivity(intent)
                    },
                )
            }
        }
        if (!permissionsGranted) {
            Button(onClick = onPermissionRequest) {'''
if needle not in s: raise SystemExit('Preview permission block not found')
# Need context in composable
sig='''  ) {
      Box(
          modifier = modifier.background'''
# extracted source formatting is normal actual file; use direct function area replacement
idx=s.index('private fun PreviewPanel(')
brace=s.index(') {',idx)+3
if 'val currentContext = LocalContext.current' not in s[brace:brace+100]:
    s=s[:brace]+'\n    val currentContext = LocalContext.current'+s[brace:]
s=s.replace(needle,block,1)
act.write_text(s)
print('PASS: quick control patch applied')
